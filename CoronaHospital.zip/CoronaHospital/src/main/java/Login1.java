import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import javax.servlet.annotation.WebServlet;
@WebServlet("/Login1")
public class Login1 extends HttpServlet
{
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException 
	{
		PrintWriter pw=res.getWriter();		//to print on the browser the response
		res.setContentType("text/html");
		String name=req.getParameter("t1");
		String email=req.getParameter("t2");
						try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
		PreparedStatement ps=con.prepareStatement("select * from register1 where t1=? and t2=?");
		ps.setString(1,name);
		ps.setString(2,email);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				res.sendRedirect("index.html");
			}
			res.sendRedirect("signin.html");
		}
				catch(Exception ae)
				{
				}
	}
				}