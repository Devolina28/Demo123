package in.nareshit.raghu.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import in.nareshit.raghu.model.Bookabed;

public interface BookabedRepository extends JpaRepository<Bookabed, Integer>
{

}
