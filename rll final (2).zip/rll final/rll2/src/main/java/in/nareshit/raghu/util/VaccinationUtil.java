package in.nareshit.raghu.util;

import org.springframework.stereotype.Component;

import in.nareshit.raghu.model.Vaccination;

@Component
public class VaccinationUtil {

	public void mapToActualObject(Vaccination actual, Vaccination vaccination) {
		
		
		actual.setName(vaccination.getName());
		actual.setAadhar(vaccination.getAadhar());
		actual.setContacts(vaccination.getContacts());
		actual.setDose(vaccination.getDose());
		actual.setVaccine(vaccination.getVaccine());
		actual.setDate2(vaccination.getDate2());
		actual.setCity(vaccination.getCity());
		actual.setTimeslot1(vaccination.getTimeslot1());
		
	}

}
