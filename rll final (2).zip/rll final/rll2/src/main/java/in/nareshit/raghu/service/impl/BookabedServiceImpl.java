package in.nareshit.raghu.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.nareshit.raghu.model.Bookabed;
import in.nareshit.raghu.repo.BookabedRepository;

import in.nareshit.raghu.service.IBookabedService;

@Service
public class BookabedServiceImpl implements IBookabedService {

	@Autowired
	private BookabedRepository repo;
	
	@Override
	public Integer saveBookabed(Bookabed f) {
		f = repo.save(f);
		return f.getId();
	}

	@Override
	public void updateStudent(Bookabed f) {
		repo.save(f);
	}

	@Override
	public void deleteBookabed(Integer id) {
		repo.deleteById(id);
	}

	@Override
	public Optional<Bookabed> getOneBookabed(Integer id) {
		return repo.findById(id);
	}

	@Override
	public List<Bookabed> getAllBookabed() {
		return repo.findAll();
	}

	@Override
	public boolean isBookabedExist(Integer id) {
		return repo.existsById(id);
	}

}
