package in.nareshit.raghu.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.nareshit.raghu.model.Vaccination;
import in.nareshit.raghu.repo.VaccinationRepository;

import in.nareshit.raghu.service.IVaccinationService;

@Service
public class VaccinationServiceImpl implements IVaccinationService {

	@Autowired
	private VaccinationRepository repo;
	
	@Override
	public Integer saveVaccination(Vaccination f) {
		f = repo.save(f);
		return f.getId();
	}

	@Override
	public void updateStudent(Vaccination f) {
		repo.save(f);
	}

	@Override
	public void deleteVaccination(Integer id) {
		repo.deleteById(id);
	}

	@Override
	public Optional<Vaccination> getOneVaccination(Integer id) {
		return repo.findById(id);
	}

	@Override
	public List<Vaccination> getAllVaccination() {
		return repo.findAll();
	}

	@Override
	public boolean isVaccinationExist(Integer id) {
		return repo.existsById(id);
	}

}
