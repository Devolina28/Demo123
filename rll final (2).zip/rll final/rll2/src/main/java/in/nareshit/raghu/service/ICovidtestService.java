package in.nareshit.raghu.service;

import java.util.List;
import java.util.Optional;

import in.nareshit.raghu.model.Covidtest;

public interface ICovidtestService {

	Integer saveCovidtest(Covidtest f);
	void updateStudent(Covidtest f);
	
	void deleteCovidtest(Integer id);

	Optional<Covidtest> getOneCovidtest(Integer id);
	List<Covidtest> getAllCovidtest();

	boolean isCovidtestExist(Integer id);
}
