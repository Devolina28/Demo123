package in.nareshit.raghu.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.nareshit.raghu.model.Ambulance;
import in.nareshit.raghu.repo.AmbulanceRepository;

import in.nareshit.raghu.service.IAmbulanceService;

@Service
public class AmbulanceServiceImpl implements IAmbulanceService {

	@Autowired
	private AmbulanceRepository repo;
	
	@Override
	public Integer saveAmbulance(Ambulance f) {
		f = repo.save(f);
		return f.getId();
	}

	@Override
	public void updateStudent(Ambulance f) {
		repo.save(f);
	}

	@Override
	public void deleteAmbulance(Integer id) {
		repo.deleteById(id);
	}

	@Override
	public Optional<Ambulance> getOneAmbulance(Integer id) {
		return repo.findById(id);
	}

	@Override
	public List<Ambulance> getAllAmbulance() {
		return repo.findAll();
	}

	@Override
	public boolean isAmbulanceExist(Integer id) {
		return repo.existsById(id);
	}

}
