package in.nareshit.raghu.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import in.nareshit.raghu.model.Covidtest;

public interface CovidtestRepository extends JpaRepository<Covidtest, Integer>
{

}
