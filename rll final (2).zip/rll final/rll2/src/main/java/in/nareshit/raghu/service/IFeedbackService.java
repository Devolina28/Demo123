package in.nareshit.raghu.service;

import java.util.List;
import java.util.Optional;

import in.nareshit.raghu.model.Feedback;

public interface IFeedbackService {

	Integer saveFeedback(Feedback f);
	void updateStudent(Feedback f);
	
	void deleteFeedback(Integer id);

	Optional<Feedback> getOneFeedback(Integer id);
	List<Feedback> getAllFeedback();

	boolean isFeedbackExist(Integer id);
}
