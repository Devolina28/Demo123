package in.nareshit.raghu.util;

import org.springframework.stereotype.Component;

import in.nareshit.raghu.model.Covidtest;

@Component
public class CovidtestUtil {

	public void mapToActualObject(Covidtest actual, Covidtest covidtest) {
		
		
		actual.setName(covidtest.getName());
		actual.setAadhar(covidtest.getAadhar());
		actual.setContacts(covidtest.getContacts());
		actual.setCity(covidtest.getCity());
		actual.setDate1(covidtest.getDate1());
		
	}

}
