package in.nareshit.raghu.util;

import org.springframework.stereotype.Component;

import in.nareshit.raghu.model.Bookabed;

@Component
public class BookabedUtil {

	public void mapToActualObject(Bookabed actual, Bookabed bookabed) {
		
		
		actual.setName(bookabed.getName());
		
		actual.setEmail(bookabed.getEmail());
		actual.setAddress(bookabed.getAddress());
		actual.setContacts(bookabed.getContacts());
		actual.setTests(bookabed.getTests());
		actual.setReport(bookabed.getReport());
		actual.setOxygen(bookabed.getOxygen());
	}

}
