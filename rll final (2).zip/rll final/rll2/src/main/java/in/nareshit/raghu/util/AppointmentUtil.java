package in.nareshit.raghu.util;

import org.springframework.stereotype.Component;

import in.nareshit.raghu.model.Appointment;

@Component
public class AppointmentUtil {

	public void mapToActualObject(Appointment actual, Appointment appointment) {
		
		
		actual.setName(appointment.getName());
		actual.setPname(appointment.getPname());
		actual.setContacts(appointment.getContacts());
		actual.setEmail(appointment.getEmail());
		actual.setReport(appointment.getReport());
		actual.setVac(appointment.getVac());
		actual.setTslot(appointment.getTslot());
	}

}
