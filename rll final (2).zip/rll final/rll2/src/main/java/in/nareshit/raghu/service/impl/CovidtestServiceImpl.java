package in.nareshit.raghu.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.nareshit.raghu.model.Covidtest;
import in.nareshit.raghu.repo.CovidtestRepository;

import in.nareshit.raghu.service.ICovidtestService;

@Service
public class CovidtestServiceImpl implements ICovidtestService {

	@Autowired
	private CovidtestRepository repo;
	
	@Override
	public Integer saveCovidtest(Covidtest f) {
		f = repo.save(f);
		return f.getId();
	}

	@Override
	public void updateStudent(Covidtest f) {
		repo.save(f);
	}

	@Override
	public void deleteCovidtest(Integer id) {
		repo.deleteById(id);
	}

	@Override
	public Optional<Covidtest> getOneCovidtest(Integer id) {
		return repo.findById(id);
	}

	@Override
	public List<Covidtest> getAllCovidtest() {
		return repo.findAll();
	}

	@Override
	public boolean isCovidtestExist(Integer id) {
		return repo.existsById(id);
	}

}
