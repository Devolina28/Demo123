package in.nareshit.raghu.service;

import java.util.List;
import java.util.Optional;

import in.nareshit.raghu.model.Appointment;

public interface IAppointmentService {

	Integer saveAppointment(Appointment f);
	void updateStudent(Appointment f);
	
	void deleteAppointment(Integer id);

	Optional<Appointment> getOneAppointment(Integer id);
	List<Appointment> getAllAppointment();

	boolean isAppointmentExist(Integer id);
}
