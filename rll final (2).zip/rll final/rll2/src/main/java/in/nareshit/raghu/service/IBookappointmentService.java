package in.nareshit.raghu.service;

import java.util.List;
import java.util.Optional;

import in.nareshit.raghu.model.Bookappointment;

public interface IBookappointmentService {

	Integer saveBookappointment(Bookappointment f);
	void updateStudent(Bookappointment f);
	
	void deleteBookappointment(Integer id);

	Optional<Bookappointment> getOneBookappointment(Integer id);
	List<Bookappointment> getAllBookappointment();

	boolean isBookappointmentExist(Integer id);
}
