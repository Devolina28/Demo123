package in.nareshit.raghu.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import lombok.Data;

@Data
@Entity
public class Covidtest {
	@Id
	@GeneratedValue
	private Integer id;
	
	public Integer getId() {
		return id;
	}
private String name;
private String aadhar;
private String contacts;
private String city;
private String date1;

public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getAadhar() {
	return aadhar;
}
public void setAadhar(String aadhar) {
	this.aadhar = aadhar;
}
public String getContacts() {
	return contacts;
}
public void setContacts(String contacts) {
	this.contacts = contacts;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public String getDate1() {
	return date1;
}
public void setDate1(String date1) {
	this.date1 = date1;
}
public void setId(Integer id) {
	this.id = id;
}


}
