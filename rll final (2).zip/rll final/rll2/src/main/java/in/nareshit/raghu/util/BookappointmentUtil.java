package in.nareshit.raghu.util;

import org.springframework.stereotype.Component;

import in.nareshit.raghu.model.Bookappointment;

@Component
public class BookappointmentUtil {

	public void mapToActualObject(Bookappointment actual, Bookappointment bookappointment) {
		
		
		actual.setDname(bookappointment.getDname());
		actual.setPname(bookappointment.getPname());
		actual.setContacts(bookappointment.getContacts());
		actual.setEmail(bookappointment.getEmail());
		actual.setReport(bookappointment.getReport());
		actual.setVac(bookappointment.getVac());
		actual.setTslot(bookappointment.getTslot());
		
	}

}
