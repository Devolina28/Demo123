package in.nareshit.raghu.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import lombok.Data;

@Data
@Entity
public class Bookappointment {
	@Id
	@GeneratedValue
	private Integer id;
	
	public Integer getId() {
		return id;
	}

	private String dname;
	private String pname;
	private String contacts;
	private String email;
	private String report;
	private String vac;
	private String tslot;

	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getContacts() {
		return contacts;
	}
	public void setContacts(String contacts) {
		this.contacts = contacts;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getReport() {
		return report;
	}
	public void setReport(String report) {
		this.report = report;
	}
	public String getVac() {
		return vac;
	}
	public void setVac(String vac) {
		this.vac = vac;
	}
	public String getTslot() {
		return tslot;
	}
	public void setTslot(String tslot) {
		this.tslot = tslot;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	
	
	
}
