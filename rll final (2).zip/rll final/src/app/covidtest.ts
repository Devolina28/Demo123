export class Covidtest {
    id: number;
    name: string;
    aadhar: string;
    contacts: string;
    city: string;
    date1: string;
}