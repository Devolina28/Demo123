import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Feedback } from './feedback';


@Injectable({
  providedIn: 'root'
})

  export class FeedbackService {

    private basePath = 'http://localhost:8090/rest/feedback';
  
    constructor(private http: HttpClient) { }
  
  
    getAllFeedbacks(): Observable<Feedback[]> {
      return this.http.get<Feedback[]>(`${this.basePath}/all`);
    }
  
    deleteOneFeedback(id: number): Observable<any> {
      return this.http.delete(`${this.basePath}/remove/${id}`, {responseType: 'text'});
    }
  
    createFeedback(feedback: Feedback): Observable<any> {
      return this.http.post(`${this.basePath}/save`, feedback, {responseType: 'text'});
    }
  
    getOneFeedback(id: number): Observable<Feedback> {
      return this.http.get<Feedback>(`${this.basePath}/one/${id}`);
    }
  
    updateFeedback(id: number, feedback: Feedback): Observable<any> {
      return this.http.put(`${this.basePath}/modify/${id}`, feedback, {responseType : 'text'});
    }
  
  
}
