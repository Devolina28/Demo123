export class Ambulance {
    id: number;
    name: string;
    contacts: string;
    address: string;
    hospital: string;
}