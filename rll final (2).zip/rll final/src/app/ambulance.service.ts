import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Ambulance } from './ambulance';


@Injectable({
  providedIn: 'root'
})

  export class AmbulanceService {

    private basePath = 'http://localhost:8090/rest/ambulance';
  
    constructor(private http: HttpClient) { }
  
  
    getAllAmbulances(): Observable<Ambulance[]> {
      return this.http.get<Ambulance[]>(`${this.basePath}/all`);
    }
  
    deleteOneAmbulance(id: number): Observable<any> {
      return this.http.delete(`${this.basePath}/remove/${id}`, {responseType: 'text'});
    }
  
    createAmbulance(ambulance: Ambulance): Observable<any> {
      return this.http.post(`${this.basePath}/save`, ambulance, {responseType: 'text'});
    }
  
    getOneAmbulance(id: number): Observable<Ambulance> {
      return this.http.get<Ambulance>(`${this.basePath}/one/${id}`);
    }
  
    updateAmbulance(id: number, ambulance: Ambulance): Observable<any> {
      return this.http.put(`${this.basePath}/modify/${id}`, ambulance, {responseType : 'text'});
    }
  
  
}
