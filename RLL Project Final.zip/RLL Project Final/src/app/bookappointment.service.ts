import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Bookappointment } from './bookappointment';


@Injectable({
  providedIn: 'root'
})

  export class BookappointmentService {

    private basePath = 'http://localhost:8090/rest/bookappointment';
  
    constructor(private http: HttpClient) { }
  
  
    getAllBookappointment(): Observable<Bookappointment[]> {
      return this.http.get<Bookappointment[]>(`${this.basePath}/all`);
    }
  
    deleteOneBookappointment(id: number): Observable<any> {
      return this.http.delete(`${this.basePath}/remove/${id}`, {responseType: 'text'});
    }
  
    createBookappointment(bookabed: Bookappointment): Observable<any> {
      return this.http.post(`${this.basePath}/save`, Bookappointment, {responseType: 'text'});
    }
  
    getOneBookappointment(id: number): Observable<Bookappointment> {
      return this.http.get<Bookappointment>(`${this.basePath}/one/${id}`);
    }
  
    updateBookappointment(id: number, bookappointment: Bookappointment): Observable<any> {
      return this.http.put(`${this.basePath}/modify/${id}`, bookappointment, {responseType : 'text'});
    }
  
  
}
