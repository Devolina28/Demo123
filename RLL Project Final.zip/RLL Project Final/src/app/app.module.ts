import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { FeedbackComponent } from './feedback/feedback.component';
import { BookabedComponent } from './bookabed/bookabed.component';
import { BookappointmentComponent } from './bookappointment/bookappointment.component';
import { AmbulanceComponent } from './ambulance/ambulance.component';
import { CovidtestComponent } from './covidtest/covidtest.component';
import { VaccinationComponent } from './vaccination/vaccination.component';
import { AppointmentComponent } from './appointment/appointment.component';
import { AboutusComponent } from './aboutus/aboutus.component';

@NgModule({
  declarations: [
    AppComponent,

    FeedbackComponent,

    BookabedComponent,

    BookappointmentComponent,

    AmbulanceComponent,

    CovidtestComponent,

    VaccinationComponent,

    AppointmentComponent,

    AboutusComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
