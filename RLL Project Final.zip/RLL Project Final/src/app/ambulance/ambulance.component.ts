import { Component, OnInit } from '@angular/core';
import { Ambulance } from '../ambulance';
import { AmbulanceService } from '../ambulance.service';

@Component({
  selector: 'app-ambulance',
  templateUrl: './ambulance.component.html',
  styleUrls: ['./ambulance.component.css']
})
export class AmbulanceComponent implements OnInit {

  ambulance: Ambulance;
  // message to ui
  message: string;

  // inject service class
  constructor(private service: AmbulanceService) { }

  ngOnInit(): void {
    // when page is loaded clear form data
    this.ambulance = new Ambulance();
  }

  // tslint:disable-next-line: typedef
  createAmbulance() {
    this.service.createAmbulance(this.ambulance)
    .subscribe(data => {
      this.message = data; // read message
      this.ambulance = new Ambulance(); // clear form
    }, error => {
      console.log(error);
    });


 }

}
