
export class Feedback {
    id: number;
    name: string;
    email: string;
    address: string;
    contacts: string;
    comments: string;
    ratings: string;
}