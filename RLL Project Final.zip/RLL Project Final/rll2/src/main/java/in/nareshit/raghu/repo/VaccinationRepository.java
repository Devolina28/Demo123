package in.nareshit.raghu.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import in.nareshit.raghu.model.Vaccination;

public interface VaccinationRepository extends JpaRepository<Vaccination, Integer>
{

}
