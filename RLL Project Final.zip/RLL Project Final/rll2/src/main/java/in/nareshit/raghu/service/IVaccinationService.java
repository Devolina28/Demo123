package in.nareshit.raghu.service;

import java.util.List;
import java.util.Optional;

import in.nareshit.raghu.model.Vaccination;

public interface IVaccinationService {

	Integer saveVaccination(Vaccination f);
	void updateStudent(Vaccination f);
	
	void deleteVaccination(Integer id);

	Optional<Vaccination> getOneVaccination(Integer id);
	List<Vaccination> getAllVaccination();

	boolean isVaccinationExist(Integer id);
}
