package in.nareshit.raghu.util;

import org.springframework.stereotype.Component;

import in.nareshit.raghu.model.Feedback;

@Component
public class FeedbackUtil {

	public void mapToActualObject(Feedback actual, Feedback feedback) {
		
		
		actual.setName(feedback.getName());
		
		actual.setEmail(feedback.getEmail());
		actual.setAddress(feedback.getAddress());
		actual.setContacts(feedback.getContacts());
		actual.setComments(feedback.getComments());
		actual.setRatings(feedback.getRatings());
	}

}
