package in.nareshit.raghu.util;

import org.springframework.stereotype.Component;

import in.nareshit.raghu.model.Ambulance;

@Component
public class AmbulanceUtil {

	public void mapToActualObject(Ambulance actual, Ambulance ambulance) {
		
		
		actual.setName(ambulance.getName());
		actual.setContacts(ambulance.getContacts());
		actual.setAddress(ambulance.getAddress());
		actual.setHospital(ambulance.getHospital());
	}

}
