package in.nareshit.raghu.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.nareshit.raghu.model.Feedback;
import in.nareshit.raghu.repo.FeedbackRepository;

import in.nareshit.raghu.service.IFeedbackService;

@Service
public class FeedbackServiceImpl implements IFeedbackService {

	@Autowired
	private FeedbackRepository repo;
	
	@Override
	public Integer saveFeedback(Feedback f) {
		f = repo.save(f);
		return f.getId();
	}

	@Override
	public void updateStudent(Feedback f) {
		repo.save(f);
	}

	@Override
	public void deleteFeedback(Integer id) {
		repo.deleteById(id);
	}

	@Override
	public Optional<Feedback> getOneFeedback(Integer id) {
		return repo.findById(id);
	}

	@Override
	public List<Feedback> getAllFeedback() {
		return repo.findAll();
	}

	@Override
	public boolean isFeedbackExist(Integer id) {
		return repo.existsById(id);
	}

}
