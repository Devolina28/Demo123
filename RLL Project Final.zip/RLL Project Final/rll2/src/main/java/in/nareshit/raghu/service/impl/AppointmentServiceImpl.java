package in.nareshit.raghu.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.nareshit.raghu.model.Appointment;
import in.nareshit.raghu.repo.AppointmentRepository;

import in.nareshit.raghu.service.IAppointmentService;

@Service
public class AppointmentServiceImpl implements IAppointmentService {

	@Autowired
	private AppointmentRepository repo;
	
	@Override
	public Integer saveAppointment(Appointment f) {
		f = repo.save(f);
		return f.getId();
	}

	@Override
	public void updateStudent(Appointment f) {
		repo.save(f);
	}

	@Override
	public void deleteAppointment(Integer id) {
		repo.deleteById(id);
	}

	@Override
	public Optional<Appointment> getOneAppointment(Integer id) {
		return repo.findById(id);
	}

	@Override
	public List<Appointment> getAllAppointment() {
		return repo.findAll();
	}

	@Override
	public boolean isAppointmentExist(Integer id) {
		return repo.existsById(id);
	}

}
