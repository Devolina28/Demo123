package in.nareshit.raghu.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.nareshit.raghu.model.Bookappointment;
import in.nareshit.raghu.repo.BookappointmentRepository;

import in.nareshit.raghu.service.IBookappointmentService;

@Service
public class BookappointmentServiceImpl implements IBookappointmentService {

	@Autowired
	private BookappointmentRepository repo;
	
	@Override
	public Integer saveBookappointment(Bookappointment f) {
		f = repo.save(f);
		return f.getId();
	}

	@Override
	public void updateStudent(Bookappointment f) {
		repo.save(f);
	}

	@Override
	public void deleteBookappointment(Integer id) {
		repo.deleteById(id);
	}

	@Override
	public Optional<Bookappointment> getOneBookappointment(Integer id) {
		return repo.findById(id);
	}

	@Override
	public List<Bookappointment> getAllBookappointment() {
		return repo.findAll();
	}

	@Override
	public boolean isBookappointmentExist(Integer id) {
		return repo.existsById(id);
	}

}
