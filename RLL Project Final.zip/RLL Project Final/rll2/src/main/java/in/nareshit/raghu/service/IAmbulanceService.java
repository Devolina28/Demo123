package in.nareshit.raghu.service;

import java.util.List;
import java.util.Optional;

import in.nareshit.raghu.model.Ambulance;

public interface IAmbulanceService {

	Integer saveAmbulance(Ambulance f);
	void updateStudent(Ambulance f);
	
	void deleteAmbulance(Integer id);

	Optional<Ambulance> getOneAmbulance(Integer id);
	List<Ambulance> getAllAmbulance();

	boolean isAmbulanceExist(Integer id);
}
