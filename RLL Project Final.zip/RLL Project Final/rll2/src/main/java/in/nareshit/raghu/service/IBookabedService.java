package in.nareshit.raghu.service;

import java.util.List;
import java.util.Optional;

import in.nareshit.raghu.model.Bookabed;

public interface IBookabedService {

	Integer saveBookabed(Bookabed f);
	void updateStudent(Bookabed f);
	
	void deleteBookabed(Integer id);

	Optional<Bookabed> getOneBookabed(Integer id);
	List<Bookabed> getAllBookabed();

	boolean isBookabedExist(Integer id);
}
