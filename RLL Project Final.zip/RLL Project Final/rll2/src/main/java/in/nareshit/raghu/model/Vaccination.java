package in.nareshit.raghu.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import lombok.Data;

@Data
@Entity
public class Vaccination {
	@Id
	@GeneratedValue
	private Integer id;
	
	public Integer getId() {
		return id;
	}

	private String name;
	private String aadhar;
	private String contacts;
	private String dose;
	private String vaccine;
	private String date2;
	private String city;
	private String timeslot1;

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAadhar() {
		return aadhar;
	}
	public void setAadhar(String aadhar) {
		this.aadhar = aadhar;
	}
	public String getContacts() {
		return contacts;
	}
	public void setContacts(String contacts) {
		this.contacts = contacts;
	}
	public String getDose() {
		return dose;
	}
	public void setDose(String dose) {
		this.dose = dose;
	}
	public String getVaccine() {
		return vaccine;
	}
	public void setVaccine(String vaccine) {
		this.vaccine = vaccine;
	}
	public String getDate2() {
		return date2;
	}
	public void setDate2(String date2) {
		this.date2 = date2;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getTimeslot1() {
		return timeslot1;
	}
	public void setTimeslot1(String timeslot1) {
		this.timeslot1 = timeslot1;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	
	
}
